export interface Linea {
  id_linea: string;        
  fecha_creacion: Date;        
  nombre_linea: string;
  origen: string;
  destino: string;
  horario: string;
  frecuencia: string;
}