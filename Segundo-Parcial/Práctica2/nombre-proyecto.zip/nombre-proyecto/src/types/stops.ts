export interface Parada {
  id_parada: string;            
  direccion: string;
  orden_parada: number;  
  created_at: Date;     
}